from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# ------------------------------------------------------
# 1️⃣ Create RDD with 5 partitions and print partitions
# ------------------------------------------------------

conf = SparkConf().setAppName("SparkAssignments").setMaster("local[*]")
sc = SparkContext(conf=conf)
spark = SparkSession(sc)

print("==== Task 1: Create RDD with 5 partitions ====")
data = [1,2,3,4,5,6,7,8,9,10,11,12]
rdd = sc.parallelize(data, 5)
print("Number of partitions:", rdd.getNumPartitions())

# ------------------------------------------------------
# 2️⃣ Create RDD from text file and count records
# ------------------------------------------------------
print("\n==== Task 2: Create RDD from text file and count records ====")
# Make sure to save your data in a file named "data.txt" in the same directory
rdd2 = sc.textFile("data.txt")
print("Number of records in text file:", rdd2.count())

# ------------------------------------------------------
# 3️⃣ Word count in paragraph
# ------------------------------------------------------
print("\n==== Task 3: Word count from paragraph ====")
text = """Python Lists allow us to hold items of heterogeneous types. In this article, 
we will learn how to create a list in Python; access the list items; find the number 
of items in the list, how to add an item to list; how to remove an item from the list; 
loop through list items; sorting a list, reversing a list; and many more transformation 
and aggregation actions on Python Lists."""

rdd3 = sc.parallelize([text])

wordCounts = (rdd3.flatMap(lambda line: line.split())
                   .map(lambda word: word.strip('.,;').capitalize())
                   .map(lambda word: (word, 1))
                   .reduceByKey(lambda a, b: a + b))

for pair in wordCounts.collect():
    print(pair)

# ------------------------------------------------------
# 4️⃣ DataFrame: Salary > 3000
# ------------------------------------------------------
print("\n==== Task 4: Users with salary > 3000 ====")

data = [("James","","Smith","36636","M",3000),
    ("Michael","Rose","","40288","M",4000),
    ("Robert","","Williams","42114","M",4000),
    ("Maria","Anne","Jones","39192","F",4000),
    ("Jen","Mary","Brown","","F",-1)
  ]

schema = StructType([
    StructField("firstname", StringType(), True),
    StructField("middlename", StringType(), True),
    StructField("lastname", StringType(), True),
    StructField("id", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("salary", IntegerType(), True)
])

df = spark.createDataFrame(data, schema)
df.createOrReplaceTempView("Users")

result = spark.sql("SELECT * FROM Users WHERE salary > 3000")
result.show()

# ------------------------------------------------------
# 5️⃣ Nested structure: Find firstname where lastname = 'Rose'
# ------------------------------------------------------
print("\n==== Task 5: Get firstname where lastname = 'Rose' ====")

structureData = [
    (("James","","Smith"),"36636","M",3100),
    (("Michael","Rose",""),"40288","M",4300),
    (("Robert","","Williams"),"42114","M",1400),
    (("Maria","Anne","Jones"),"39192","F",5500),
    (("Jen","Mary","Brown"),"","F",-1)
]

structureSchema = StructType([
    StructField('name', StructType([
        StructField('firstname', StringType(), True),
        StructField('middlename', StringType(), True),
        StructField('lastname', StringType(), True)
    ])),
    StructField('id', StringType(), True),
    StructField('gender', StringType(), True),
    StructField('salary', IntegerType(), True)
])

df2 = spark.createDataFrame(structureData, schema=structureSchema)
df2.createOrReplaceTempView("Users")

result2 = spark.sql("SELECT name.firstname FROM Users WHERE name.lastname = 'Rose'")
result2.show()

# ------------------------------------------------------
# ✅ Stop SparkContext
# ------------------------------------------------------
sc.stop()
